# Phantom pureapi

It is just a framework that flies in my mind,
and I always wanted to see if I can benefit from it